<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "test";
$formuname = $_POST['username'];
$formpword = $_POST['password'];
$formemail = $_POST['email'];
$formfirst = $_POST['first'];
$formlast = $_POST['last'];
$hashedPassword = md5($formpword);
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO korisnik ( username, email, password, first, last, status)
VALUES ('$formuname', '$formemail', '$hashedPassword', '$formfirst', '$formlast', 1)";




if ($conn->query($sql) === TRUE) {
  header("Location: ../index.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>