<?php
session_start();
   unset($_SESSION["formuname"]);
   unset($_SESSION["password"]);
   unset($_SESSION["id"]);
   unset($_SESSION["formemail"]);
   
   echo 'You have cleaned session';
   header('Location: ../loginpage.php');
   ?>