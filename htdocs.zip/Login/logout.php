<?php
session_start();
   unset($_SESSION["formuname"]);
   unset($_SESSION["password"]);
   
   echo 'You have cleaned session';
   header('Location: ../loginpage.php');
   ?>