<?php

session_start();

// Variable i connect
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";
$formuser = $_POST['username'];
$formpword = $_POST['password'];
$conn = new mysqli($servername, $username, $password, $database);


// Connect Error
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// Ovo je da moze da uporedi hashed sa hashed
$hashedPassword = md5($formpword);

//find row
$sql = "SELECT username, password FROM korisnik WHERE username = '$formuser'";
$result = $conn->query($sql);
$sqlemail = "SELECT email, password FROM korisnik WHERE email = '$formuser'";
$resultemail = $conn->query($sqlemail);
// Test username i pass
if ($result->num_rows > 0) { 
    
    while($row = $result->fetch_assoc()) {
        
        $password_korisnik = $row['password'];
        $_SESSION["formuname"] = $row['username'];
        if (md5($password_korisnik) == md5($hashedPassword)){
            
            $sql1 = "SELECT email, password FROM korisnik WHERE username = '$formuser'";
            $result1 = $conn->query($sql1);
            while($row1 = $result1->fetch_assoc()) {
                $_SESSION['id']=$row1['id'];
                $_SESSION['email'] = $row1['email'];
                header("Location: ../index.php");

            }
            
        }
    }
}
else if($resultemail->num_rows > 0){
    while($rowemail = $resultemail->fetch_assoc()) {
        $password_korisnik = $rowemail['password'];
        $_SESSION["formemail"] = $rowemail['email'];
        if (md5($password_korisnik) == md5($hashedPassword)){
            $sql2 = "SELECT username, password FROM korisnik WHERE email = '$formuser'";
            $result2 = $conn->query($sql2);
            while($row2 = $result2->fetch_assoc()) {
                $id = $rowemail['id'];
                $_SESSION['id']=$id;
                $user = $row2['username'];
                $_SESSION['user'] = $user;
                header("Location: ../index.php");
            }
        }
        else{
            echo("Wrong credentials!");
            }
        }
}
    else{
        echo("Wrong credentials!");
    }

$conn->close();
?>