<?php

session_start();

// Variable i connect
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";
$formuser = $_POST['username'];
$formpword = $_POST['password'];
$conn = new mysqli($servername, $username, $password, $database);


// Connect Error
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// Ovo je da moze da uporedi hashed sa hashed
$hashedPassword = md5($formpword);

// Test username i pass
$sql = "SELECT username, password FROM korisnik WHERE username = '$formuser'";
$result = $conn->query($sql);
if ($result->num_rows > 0) { 
    while($row = $result->fetch_assoc()) {
        $id = $row['id'];
        $password_korisnik = $row['password'];
        $_SESSION["formuname"] = $row['username'];
        if (md5($password_korisnik) == md5($hashedPassword)){
            $_SESSION["formemail"] = $rowemail['email'];
            header("Location: ../index.php");
        }
    }
}
    $sqlemail = "SELECT email, password FROM korisnik WHERE email = '$formuser'";
    $resultemail = $conn->query($sqlemail);
    if($resultemail->num_rows > 0){
        while($rowemail = $resultemail->fetch_assoc()) {
            $eid = $rowemail['id'];
            $epassword_korisnik = $rowemail['password'];
            $_SESSION["formmail"] = $rowemail['email'];
            if (md5($epassword_korisnik) == md5($hashedPassword)){
                $_SESSION["formuser"] = $rowemail['username'];
                header("Location: ../index.php");
            }
            else{
                echo("Wrong credentials!");
                }
            }
    }

$conn->close();
?>
            <!-- $_SESSION["formemail"] = $rowemail['email'];
            $_SESSION["formuser"] = $rowemail['username']; -->