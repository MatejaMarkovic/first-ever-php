<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,100&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="CSS/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="CSS/profile.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Home | Amplitudo</title>
</head>
<body >
    <div class="stars">
        <div class="twinkling">
            <div class="clouds">
            <div class="header">
                <h1 id="amplitudotxt">Amplitudo
                    <a id="hometxt" class="texthead" href="index.php">Home </a>
                    <a id="aboutustxt" class="texthead" href="aboutus.php">About Us </a>
                    <?php
                        if(isset($_SESSION["formuname"])){ 
                            echo '<a id="profiletxt" class="texthead" href="profile.php">Profile</a>';
                            echo '<a id="logintxt" class="texthead" href="Login/logout.php">Log Out </a>';
                        }
                        else if(isset($_SESSION["formuser"])){
                            echo '<a id="registertxt" class="texthead" href="profile.php">Profile</a>';
                            echo '<a id="logintxt" class="texthead" href="Login/logout.php">Log Out </a>';
                        }
                        else{
                            echo '<a id="registertxt" class="texthead" href="registerpage.php">Register </a>';
                            echo '<a id="logintxt" class="texthead" href="loginpage.php">Log In </a>';
                        }
                    ?>
                </h1>
                <?php
                if(isset($_SESSION["formuser"])){
                    $formuser = $_SESSION["formuser"];
                    $formmail = $_SESSION["formmail"];
                    echo "<p class='loggedin'>You are logged in as $formuser</p>";
                    echo "<p class='emaildisplay'>Email: $formemail</p>";
                }
                else{
                    $formuname = $_SESSION["formuname"];
                    $formemail = $_SESSION["formemail"];
                    echo "<p class='loggedin'>You are logged in as $formuname</p>";
                    echo "<p class='emaildisplay'>Email: $formemail</p>";
                }
                ?>

                 
                <form action="Profile/upload.php" method="post" enctype="multipart/form-data">
                    <input type="file" name="file">
                    <button type="submit" name="upload">Upload</button>
                </form>
            </div>
            </div>
        </div>
    </div>

<script>
</script>
</body>
</html>